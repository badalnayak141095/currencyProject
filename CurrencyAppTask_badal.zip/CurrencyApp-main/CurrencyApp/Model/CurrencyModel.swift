//
//  CurrencyModel.swift
//  CurrencyApp
//
//  Created by badal on 01/12/22.
//

import Foundation

struct CurrencyModel {
    var currencySymbol: String
    var currencyValue: String
}
